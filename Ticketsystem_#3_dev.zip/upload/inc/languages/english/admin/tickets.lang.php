<?php
$l['setting_group_tickets'] = "Ticketsystem Options";
$l['setting_group_tickets_desc'] = "Manage your Ticketsystem here";
$l['setting_tickets_usergroups'] = "Usergroup which can reply to tickets?";
$l['setting_tickets_usergroups_desc'] = "Seperate by comma. All members of this groups can replay and close tickets. Default: \"3,4\" (Admin and Super Mod)";
?>