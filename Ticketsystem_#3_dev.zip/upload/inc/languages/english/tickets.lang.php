<?php
$l['toplinks_tickets'] = "Ticketsystem";
$l['ticket'] = "Ticket";
$l['tickets'] = "Tickets";
$l['tickets_deactivated'] = "Ticketsystem is deactivated";
$l['no_id'] = "No ID send";
$l['wrong_id'] = "Wrong ID send";
$l['tickets_admin'] = "Admin Section";

$l['ticket_title'] = "Title";
$l['ticket_created_at'] = "Created";
$l['ticket_answers'] = "Replys";

$l['tickets_show_closed'] = "Show closed tickets too";

$l['ticket_closed'] = "Ticket sucessfully closed";
$l['ticket_answered'] = "Answer sucessfully saved";

$l['ticket_no_subject'] = "No title specified";
$l['ticket_no_ticket'] = "No ticket specified";
$l['ticket_created'] = "Ticket sucessfully created";
$l['ticket_create'] = "Create ticket";
$l['ticket_new'] = "New ticket";

$l['tickets_nothing'] = "No tickets to view";

$l['tickets_answer'] = "Reply to ticket";
$l['ticket_close'] = "Close";

$l['myalerts_setting_MyBBS_tickets_new_ticket'] = "Receive alert for new tickets?";
$l['myalerts_setting_MyBBS_tickets_new_answer'] = "Receive alert for new answers on tickets?";
$l['myalerts_format_tickets_new_ticket'] = "{1} created a new ticket <a href=\"{3}\">{4}</a> ({2})";
$l['myalerts_format_tickets_new_answer'] = "{1} replied to the ticket <a href=\"{3}\">{4}</a> ({2})";

$l['tickets_wio'] = "Viewing the <a href=\"tickets.php\">Ticketsystem</a>";