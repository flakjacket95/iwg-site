<?php
$l['toplinks_tickets'] = "Ticketsystem";
$l['ticket'] = "Ticket";
$l['tickets'] = "Tickets";
$l['tickets_deactivated'] = "Das Ticketsystem ist momentan deaktiviert";
$l['no_id'] = "Es wurde keine ID übermittelt";
$l['wrong_id'] = "Es wurde eine fehlerhafte ID übermittelt";
$l['tickets_admin'] = "Admin Bereich";

$l['ticket_title'] = "Titel";
$l['ticket_created_at'] = "Erstellt";
$l['ticket_answers'] = "Anworten";

$l['tickets_show_closed'] = "Zeige auch geschlossene Tickets";

$l['ticket_closed'] = "Ticket erfolgreich geschlossen";
$l['ticket_answered'] = "Antwort erfolgreich gespeichert";

$l['ticket_no_subject'] = "Keinen Titel angegeben";
$l['ticket_no_ticket'] = "Kein Ticket angegeben";
$l['ticket_created'] = "Ticket erfolgreich erstellt";
$l['ticket_create'] = "Ticket erstellen";
$l['ticket_new'] = "Neues Ticket";

$l['tickets_nothing'] = "Es gibt keine anzuzeigenden Tickets";

$l['tickets_answer'] = "Beantworte Tickets";
$l['ticket_close'] = "Schließen";
?>