<?php
$l['setting_group_tickets'] = "Einstellung für das Ticketsystem";
$l['setting_group_tickets_desc'] = "Hier lassen sich die Zugriffsrechte für das Ticketsystem einstellen";
$l['setting_tickets_usergroups'] = "Welche Nutzergruppen dürfen auf Tickets antworten?";
$l['setting_tickets_usergroups_desc'] = "Durch Kommata trennen. Alle Mitglieder dieser Gruppen können Tickets beantworten und diese schließen. Default: \"3,4\" (Administratoren und Super Moderatoren)";
?>