<?php
$l['setting_group_tickets'] = "Opções do Sistema de Bilhetes";
$l['setting_group_tickets_desc'] = "Gerencie aqui o sistema de bilhetes";
$l['setting_tickets_usergroups'] = "Grupo de usuários que podem responder bilhetes?";
$l['setting_tickets_usergroups_desc'] = "Separado por virgulas - todos os grupos que podem responder e fechar bilhetes. Padrão: \"3,4\" (Admin and Super Mod)";
?>
