<?php
$l['toplinks_tickets'] = "Sistema de Bilhetes";
$l['ticket'] = "Bilhete";
$l['tickets'] = "Bilhetes";
$l['tickets_deactivated'] = "Sistema de Bilhetes está desativado";
$l['no_id'] = "ID não enviado";
$l['wrong_id'] = "ID errado enviado";
$l['tickets_admin'] = "Seção Administrativa";

$l['ticket_title'] = "Título";
$l['ticket_created_at'] = "Criado";
$l['ticket_answers'] = "Respostas";

$l['tickets_show_closed'] = "Mostrar bilhetes fechados também";

$l['ticket_closed'] = "Bilhete fechado com sucesso";
$l['ticket_answered'] = "Resposta salva com sucesso";

$l['ticket_no_subject'] = "Sem título especificado";
$l['ticket_no_ticket'] = "Sem bilhete especificado";
$l['ticket_created'] = "Bilhete criado com sucesso";
$l['ticket_create'] = "Criar bilhete";
$l['ticket_new'] = "Novo bilhete";

$l['tickets_nothing'] = "Sem bilhetes para ver";

$l['tickets_answer'] = "Responder bilhete";
$l['ticket_close'] = "Fechado";
?>
