<?php

class MyBBS_Tickets_Version_Manager extends JB_Version_Manager
{
	protected static $codename = "tickets";
	protected static $versions = array(
		"1.1"
	);
}