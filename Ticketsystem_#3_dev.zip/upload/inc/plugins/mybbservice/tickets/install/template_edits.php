<?php

$edits = array(
	"header" => array(
		'{$menu_portal}' => '<li><a href="{$mybb->settings[\'bburl\']}/tickets.php" style="background-position: 0 20px;"><img src="images/toplinks/tickets.gif" alt="" title="" />{$lang->toplinks_tickets}</a></li>
		{$menu_portal}',
	),
);