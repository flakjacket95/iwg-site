<?php

$alerts = array(
	"new_ticket",
	"new_answer",
);