# Overview
Simple reversing problem. There are a few ways to solve it:
  1) Do it statically, it's not hard
  2) Call the check\_one function with 0 for the first arg, it will return the negative of whatever you want.
  3) Brute force with instruction counting character by character
