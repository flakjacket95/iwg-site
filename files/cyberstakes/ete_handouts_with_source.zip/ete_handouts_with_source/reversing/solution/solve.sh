#! /bin/sh

current_guess="$1"

charset="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"

cat > gdbscript <<EOF
set height 0
b *0x804844d
ignore 1 999999999
r
info breakpoints
quit
EOF

start='999999998'
for i in `seq 20`; do
  for c in $charset; do
    guess="$current_guess$c"
    a=$(gdb ../bin/reverseme_strip -x gdbscript --args ../bin/reverseme_strip ${guess}_| tail -1  | cut -d ' ' -f 3)
    if [ $a != $start ]; then
      start=$a
      current_guess=${current_guess}$c 
      echo $current_guess;
      ../bin/reverseme_strip $current_guess;
      break
    fi
  done
done
