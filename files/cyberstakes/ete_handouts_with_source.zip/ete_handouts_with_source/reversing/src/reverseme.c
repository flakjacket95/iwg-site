/* This is where you would put source files */
#include <stdio.h>

int check_one(char s, int i) {
  if (i > 20) {
    return i;
  }
  return s - (0x53^(((i^3)*(i^3))&0x1f));
}

int check(char* secret) {
  int i,s;

  for (i = 0; secret[i]; i++) {
    s = check_one(secret[i],i);
    if (s) {
      return s;
    }
  }
  return 20-i;
}

int main(int argc, char** argv)
{
  if (argc != 2) {
    puts("WHERE IS THE PASSWORD?!?!");
    return -1;
  }
  if (!check(argv[1])) {
    printf("Correct! The flag is %s\n",argv[1]);
  }
  else {
    puts("Incorrect :(");
  }
  return 0;
}
