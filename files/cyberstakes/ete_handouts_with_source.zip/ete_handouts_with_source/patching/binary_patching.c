#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/ptrace.h>

#ifndef PTRACE_TRACEME
#define PTRACE_TRACEME PT_TRACE_ME
#endif

int is_authorized_machine() {
	char buf[13];
	buf[12] = 0;
	asm volatile (
		"xorl  %%eax,%%eax \n"
		"cpuid \n"
		"xchg %0, %%esp \n"
		"push %%ecx\n"
		"push %%edx\n"
		"push %%ebx\n"
		"xchg %0, %%esp \n"
		:
		: "r" (&buf[12])
		: "eax", "ebx", "edx", "ecx"
	);
	return !strcmp(buf, "SuperSpecial");
}

static int four() {
	return 4;
}

int main() {
	srand(time(NULL));
	int (*getrand)(void) = &rand;
	
	if(ptrace(PTRACE_TRACEME, 0, 0 ,0) < 0) {
		// Mess with debuggers!
		getrand = &four;
	}
	
	if(!is_authorized_machine()) {
		fprintf(stderr, "Not authorized!");
		exit(0);
	}
	
	puts("I'm an echo service AND a random number service.");
	puts("Two in one! Double for nothing! WOW!");
	
	char buf[40];
	fgets(buf, 100, stdin);
	
	if(is_authorized_machine()) {
		printf("%d\n%s\n", getrand(), buf);
	} else {
		puts("...");
	}
}
