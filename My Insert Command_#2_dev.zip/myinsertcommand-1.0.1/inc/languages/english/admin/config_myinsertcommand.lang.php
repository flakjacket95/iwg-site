<?php

$l['myinsertcommand_plug_desc'] = 'Insert new command in Sceditor';
$l['myinsertcommand_sett_desc'] = 'Settings related to the My Insert Command.';
$l['myinsertcommand_rules_title'] = 'Add "Insert..." button in Clickable MyCode Editor';
$l['myinsertcommand_rules_desc'] = 'Enter the command name, command expression and set if command has or no description. You must make sure the rule is valid and safe—no validation is performed. Separate rules with ";".<br /><strong>Example:</strong> Spoiler tag,spoiler,yes';

?>